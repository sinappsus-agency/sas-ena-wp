=== WooCommerce Teljoy Gateway ===
Contributors: sinappsus, jacques artgraven, teljoy
Tags: credit card, Teljoy, payment request, woocommerce
Requires at least: 6.0
Tested up to: 6.0
Requires PHP: 7.4
Stable tag: 0.0.2
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This is the official ENA wordpress plugin

== Description ==

This is a completely internal plugin created by Sinappsus for ENA and its partners to connect with the core system

== Frequently Asked Questions ==

= Does this require a merchant account? =

Yes! A merchant account and organization must first be setup with Eagles Nest

= Does this require an SSL certificate? =

An SSL certificate is recommended for additional safety and security for your customers.

= Where can I find documentation? =

For help setting up and configuring, please refer to our [user guide](#)

= Where can I get support or talk to other users? =

If you get stuck, you can contact support@teljoy.co.za

== Changelog ==
= 0.0.1 - 2024-09-17 =
* Init - First setup and test.