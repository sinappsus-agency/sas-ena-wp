<?php
$environments = array();
$environments["sandbox"]     =    array(
    "api_url"    =>    "https://api-ena.sinappsus.us/api/",
);

$environments["production"] =    array(
    "api_url"    =>    "https://api-ena.sinappsus.us/api/",
);
